/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  env: {
    url:"https://vnexpress.net/chu-tich-nuoc-den-tokyo-bat-dau-tham-chinh-thuc-nhat-ban-4681507.html"
  },
}

module.exports = nextConfig
